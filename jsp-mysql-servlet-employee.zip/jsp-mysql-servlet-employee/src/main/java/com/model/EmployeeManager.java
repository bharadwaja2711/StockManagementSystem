package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EmployeeManager {
	String url="jdbc:mysql://localhost:3306/kludb";
	String username="root";
	String password="gaman2004";
	Connection con=null;
	PreparedStatement ps=null;
	List<Employee> l=new ArrayList<Employee>();
	public List<Employee> readData() {
		try {
			con=DriverManager.getConnection(url,username,password);
			ps=con.prepareStatement("select * from employee");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Employee e=new Employee();
				e.setEid(rs.getInt(1));
				e.setEname(rs.getString(2));
				e.setEdept(rs.getString(3));
				e.setEsalary(rs.getInt(4));
				l.add(e);   
			}
		}
		catch(Exception e) {
			
		}
		return l;  
	}
	public String insertData(Employee e)
	 {
	  try
	  {
	  con=DriverManager.getConnection(url,username,password);
	  ps=con.prepareStatement("insert into employee values(?,?,?,?)");
	  ps.setInt(1, e.getEid());
	  ps.setString(2,e.getEname());
	  ps.setString(3,e.getEdept());
	  ps.setInt(4,e.getEsalary());
	  ps.execute();
	  con.close();
	    }
	  catch(Exception e1)
	  {
	  }
	  return "insertion done successfully";
	   
	 }
	public String updateData(Employee e) throws Exception{
		con=DriverManager.getConnection(url, username, password);
		ps=con.prepareStatement("update employee set ename=?, edept=?, esalary=? where eid=?");
		ps.setString(1, e.getEname());
		ps.setString(2, e.getEdept());
		ps.setInt(3, e.getEsalary());
		ps.setInt(4, e.getEid());
		ps.execute();
		con.close();
		return "updation done successfully";
	}
	public String deleteData(int eid) throws Exception{
		con=DriverManager.getConnection(url, username, password);
		ps=con.prepareStatement("delete from employee where eid=?");
		ps.setInt(1, eid);
		ps.executeUpdate();
		con.close();
		return "deletion done successfully";
	}
}
