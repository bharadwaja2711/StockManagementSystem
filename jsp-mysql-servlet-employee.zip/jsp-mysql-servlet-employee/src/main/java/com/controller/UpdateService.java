package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Employee;
import com.model.EmployeeManager;

public class UpdateService extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		Employee e=new Employee();
		int eid=Integer.parseInt(request.getParameter("id"));
		String ename=request.getParameter("name");
		String edept=request.getParameter("dept");
		int esalary=Integer.parseInt(request.getParameter("salary"));
		e.setEid(eid);
		e.setEname(ename);
		e.setEdept(edept);
		e.setEsalary(esalary);
		
		EmployeeManager em=new EmployeeManager();
		
		try {
			pw.print(em.updateData(e));
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		RequestDispatcher rd=request.getRequestDispatcher("update.jsp");
		rd.include(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
