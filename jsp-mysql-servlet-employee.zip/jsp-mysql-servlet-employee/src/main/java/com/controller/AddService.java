package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Employee;
import com.model.EmployeeManager;

public class AddService extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
	    PrintWriter pw=response.getWriter();
	    EmployeeManager em=new EmployeeManager();

	    Employee e=new Employee();
	    int eid=Integer.parseInt(request.getParameter("eid"));
	    String ename=request.getParameter("ename");
	    String edept=request.getParameter("edept");
	    int esal=Integer.parseInt(request.getParameter("esalary"));
	    e.setEid(eid);
	    e.setEname(ename);
	    e.setEdept(edept);
	    e.setEsalary(esal);
	    String ack=em.insertData(e);
	    pw.print(ack);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
